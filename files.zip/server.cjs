const express = require('express');
const cors = require('cors');

const app = express();

app.use(express.json());
app.use(cors({
  origin: 'http://localhost:8080',
  credentials: true
}));

app.get('/', (req, res) => {
  res.json({ status: '✅ Backend is running on port 3000!' });
});

app.post('/api/chat', async (req, res) => {
  try {
    const { message } = req.body;

    if (!message) {
      return res.status(400).json({ error: 'Message is required' });
    }

    console.log(`\n📨 User message: "${message}"`);
    console.log('🔄 Calling Ollama API...');

    const ollamaResponse = await fetch('http://127.0.0.1:11434/api/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'llama3',
        messages: [{ role: 'user', content: message }],
        stream: false,
      }),
    });

    if (!ollamaResponse.ok) {
      throw new Error(`Ollama returned ${ollamaResponse.status}`);
    }

    const ollamaData = await ollamaResponse.json();
    const aiReply = ollamaData.message?.content || 'No response from AI';

    console.log(`✅ Got reply from Ollama`);
    console.log(`📤 Sending back to frontend\n`);

    return res.json({ reply: aiReply });

  } catch (error) {
    console.error(`\n❌ Ollama error: ${error.message}`);
    console.log('⚠️ Using fallback response\n');

    const fallbackReplies = [
      `أنت قلت: "${req.body.message}" - وهذا رد من السيرفر! 🤖`,
      `شكراً على الرسالة: "${req.body.message}" - Backend يعمل بشكل جيد! ✨`,
      `رسالتك تم استقبالها: "${req.body.message}" - الاتصال ناجح! 🎉`,
    ];

    const fallbackReply = fallbackReplies[Math.floor(Math.random() * fallbackReplies.length)];
    res.json({ reply: fallbackReply });
  }
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`\n${'='.repeat(50)}`);
  console.log(`✅ BACKEND SERVER STARTED`);
  console.log(`${'='.repeat(50)}`);
  console.log(`📍 Server: http://localhost:${PORT}`);
  console.log(`📡 Ollama: http://localhost:11434`);
  console.log(`✨ Model: llama3`);
  console.log(`✨ Ready for chat requests\n`);
});
